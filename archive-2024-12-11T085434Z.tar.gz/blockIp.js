const ipware = require('ipware')();
const fs = require('fs-extra');

module.exports = function (req, res, next) {
  try {
    // Extract the client's IP address
    const clientIP = ipware.get_ip(req).clientIp;

    if (!clientIP) {
      console.error('Unable to detect client IP');
      return res.status(500).send({
        AUTHOR: 'Anup Kumar',
        STATUS: 'ERROR',
        MESSAGE: 'Could not determine client IP.',
      });
    }

    // Load blocked IPs from the JSON file
    const blockedIPsFile = './blockedIP.json';
    if (!fs.existsSync(blockedIPsFile)) {
      console.error('Blocked IPs file is missing:', blockedIPsFile);
      return res.status(500).send({
        AUTHOR: 'Anup Kumar',
        STATUS: 'ERROR',
        MESSAGE: 'Server configuration issue: Blocked IPs file missing.',
      });
    }

    const blockedIPs = JSON.parse(fs.readFileSync(blockedIPsFile, { encoding: 'utf-8' }));

    console.log('Blocked IPs:', blockedIPs);
    console.log('Client IP attempting to access:', clientIP);

    // Check if the client IP is blocked
    if (blockedIPs.includes(clientIP)) {
      console.log(`Blocking IP: ${clientIP}`);
      return res.status(403).send({
        AUTHOR: 'Anup Kumar',
        STATUS: 'ERROR 403',
        MESSAGE: 'Access denied. You are blocked.',
        INBOX: 'INB FACEBOOK INB FACEBOOK IF YOU WANT TO LOOK BECAUSE I DONT REP',
      });
    }

    // Allow the request to proceed if IP is not blocked
    console.log('IP allowed, proceeding...');
    next();
  } catch (error) {
    console.error('Middleware failed:', error);

    res.status(500).send({
      AUTHOR: 'Anup Kumar',
      STATUS: 'ERROR',
      MESSAGE: 'An unexpected server error occurred.',
    });
  }
};
