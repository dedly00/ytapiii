'use strict';
var starttime = new Date().getTime();
const express = require("express");
const cors = require("cors");
const fs = require("fs-extra");
const helmet = require("helmet");
const path = require('path');
const ytdl = require('@distube/ytdl-core');
const ffmpeg = require('fluent-ffmpeg');

const server = require("./server.js");
var fbdl = require('./amy/fbdl.js');
const app = express();
const rateLimit = require("express-rate-limit");
const getIP = require('ipware')().get_ip;
const checkIPBlocked = require('./blockIp.js');
const blockedIPs = JSON.parse(fs.readFileSync('./blockedIP.json', { encoding: 'utf-8' }));
const handleBlockIP = rateLimit({
    windowMs: 60 * 1000,
    max: 650,
    handler: function (req, res, next) {
        const ipInfo = getIP(req);
        const ip = ipInfo.clientIp;
        if (!blockedIPs.includes(ip)) {
            blockedIPs.push(ip);
            fs.writeFileSync('./blockedIP.json', JSON.stringify(blockedIPs, null, 2));
            console.log(`[ RATE LIMIT ] → Blocked IP: ${ip}`);
        }
        next();
    }
});
const DOWNLOAD_DIR = path.join(__dirname, 'downloads');

// Ensure the download directory exists
if (!fs.existsSync(DOWNLOAD_DIR)) {
    fs.mkdirSync(DOWNLOAD_DIR);
}

// Read cookies from the cookies.txt file
let cookies;
try {
    cookies = fs.readFileSync('cookies.txt', 'utf8').trim();
} catch (err) {
    console.error('Error reading cookies.txt:', err);
}

// New `/download` route for video/audio download
app.get('/download', async (req, res) => {
    const videoUrl = req.query.url;
    const format = req.query.format || 'video';  // Default to 'video' if format is not specified

    if (!videoUrl) {
        return res.status(400).json({ error: 'URL is required' });
    }

    try {
        const videoId = ytdl.getURLVideoID(videoUrl);
        let filePath;

        if (format === 'audio') {
            // Prepare file path for audio
            filePath = path.join(DOWNLOAD_DIR, `${videoId}_360p.mp4`);
            const mp3Path = path.join(DOWNLOAD_DIR, `${videoId}.mp3`);

            // Download video for audio extraction
            const videoStream = ytdl(videoUrl, {
                quality: '18',  // 360p quality for MP4 download
                requestOptions: {
                    headers: {
                        Cookie: cookies,  // Use cookies if required
                    },
                },
            });

            const writeStream = fs.createWriteStream(filePath);
            videoStream.pipe(writeStream);

            writeStream.on('finish', () => {
                // Convert to MP3 after download
                ffmpeg(filePath)
                    .toFormat('mp3')
                    .save(mp3Path)
                    .on('end', () => {
                        res.json({
                            message: "Audio downloaded and converted successfully.",
                            audio: `http://51.161.207.163:1800/downloads/${videoId}.mp3`,  // Serve MP3 file
                        });

                        // Clean up files after 5 minutes
                        setTimeout(() => {
                            fs.unlink(filePath, (err) => {
                                if (err) console.error('Error deleting video file:', err);
                            });
                            fs.unlink(mp3Path, (err) => {
                                if (err) console.error('Error deleting audio file:', err);
                            });
                        }, 300000); // 5 minutes
                    })
                    .on('error', (err) => {
                        console.error('Error converting to MP3:', err);
                        res.status(500).json({ error: 'Error converting video to MP3' });
                    });
            });

            videoStream.on('error', (error) => {
                console.error('Error downloading video for audio conversion:', error);
                res.status(500).json({ error: 'Error downloading video for audio conversion' });
            });

            writeStream.on('error', (error) => {
                console.error('Error writing video file for audio conversion:', error);
                res.status(500).json({ error: 'Error saving video file' });
            });

        } else {
            // Prepare file path for video
            filePath = path.join(DOWNLOAD_DIR, `${videoId}_360p.mp4`);

            // Download video in 360p quality
            const videoStream = ytdl(videoUrl, {
                quality: '18',  // 360p quality for MP4 download
                requestOptions: {
                    headers: {
                        Cookie: cookies,  // Use cookies if required
                    },
                },
            });

            const writeStream = fs.createWriteStream(filePath);
            videoStream.pipe(writeStream);

            writeStream.on('finish', () => {
                res.json({
                    message: "Video downloaded successfully.",
                    video: `http://51.161.207.163:1800/downloads/${videoId}_360p.mp4`,  // Serve video file
                });

                // Clean up video file after 5 minutes
                setTimeout(() => {
                    fs.unlink(filePath, (err) => {
                        if (err) console.error('Error deleting video file:', err);
                    });
                }, 300000); // 5 minutes
            });

            videoStream.on('error', (error) => {
                console.error('Error downloading video:', error);
                res.status(500).json({ error: 'Error downloading video' });
            });

            writeStream.on('error', (error) => {
                console.error('Error writing video file:', error);
                res.status(500).json({ error: 'Error saving video file' });
            });
        }
    } catch (error) {
        console.error('Error processing download:', error);
        res.status(500).json({ error: 'Error processing download' });
    }
});

// Serve static files from the downloads directory
app.use('/downloads', express.static(DOWNLOAD_DIR));
app.use(handleBlockIP);
app.use(checkIPBlocked);
app.use(helmet());
app.use(express.json());
app.use(cors());
app.use(function(req, res, next) {
    var ipInfo = getIP(req);
    var color = ["\x1b[31m", "\x1b[32m", "\x1b[33m", '\x1b[34m', '\x1b[35m', '\x1b[36m', '\x1b[37m', "\x1b[38;5;205m", "\x1b[38;5;51m", "\x1b[38;5;197m", "\x1b[38;5;120m", "\x1b[38;5;208m", "\x1b[38;5;220m", "\x1b[38;5;251m"];
    var more = color[Math.floor(Math.random() * color.length)];
    console.log(more + '[ IP ] → ' + ipInfo.clientIp + ' - I have requested a folder:' + decodeURIComponent(req.url));
    next();
});
app.post('/')
app.use("/", server);
app.use('/fbdl', fbdl);
app.set("json spaces", 4);
app.use((error, req, res, next) => {
    res.status(error.status).json({ message: error.message });
});
///////////////////////////////////////////////////////////
//========= Create website for dashboard/uptime =========//
///////////////////////////////////////////////////////////
app.set('port', (process.env.PORT || 1800));
app.get('/', function(req, res) {
   res.sendFile(__dirname + '/index.html');
  
}).listen(app.get('port'), function() {
    console.log('\x1b[36m=====================================================\n\x1b[38;5;220m[ START ] \x1b[33m→\x1b[38;5;119m The server Dark Rulex is running on PORT\x1b[38;5;208m', app.get('port'), '\n\x1b[36m=====================================================\n');
});

var totaltime = (new Date().getTime() - starttime)/1000;
console.log("\x1b[38;5;220m[ LOADING ] \x1b[33m→\x1b[35m Start-up time: "+Math.round(totaltime*100)/100+" ms");
console.log("\x1b[38;5;205m[ ANUP API ] \x1b[33m→\x1b[38;5;51mSuccessfully started Dark Rulex API");
// bank
//async function bank() {
//const { writeFileSync } = require('fs-extra');
//const { join } = require('path');
//const pathData = join(__dirname, "public", "bank", "data", "bank.json");
//const user = require('./public/bank/data/bank.json');
    //if(user[0] == undefined ) return
    //while(true) {
	    //for (let id of user) {
		    //var userData = user.find(i => i.senderID == id.senderID);
		    //var money = userData.data.money;
		    //userData.data.money = parseInt(money) + parseInt(money) * 0.005
		    //writeFileSync(pathData, JSON.stringify(user, null, 2));
    	
	    //console.log("\x1b[38;5;220m[ BANKING ] \x1b[33m→ \x1b[35mIn the process of processing banking ...");
	    //await new Promise(resolve => setTimeout(resolve, 60 * 60 * 1000))
    

//bank()
// -------------------------->      END     <-------------------------------//