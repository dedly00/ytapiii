const { errorHandler } = require("../utils");

exports.punch = async (req, res, next) => {
  var data = require('fs-extra').readFileSync(__dirname + '/../Neha/punch.txt', 'utf-8').split('\n');
  link = data[Math.floor(Math.random() * data.length)].trim();
  res.json({"data":"Anup Kumar","url":`${link}`});
};