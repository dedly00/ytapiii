const express = require('express')

var router = express.Router();



const hikkiMe = require('hikki-me')
const axios = require('axios')

const fetch = require('node-fetch')

__path = process.cwd()

const fs = require('fs')

//scraper

router.get('/fbdl3', async (req, res) => {

  var link = req.query.link

  if (!link) return res.json({ message: 'masukan parameter Link' })

  var hasil = await hikkiMe.downloader.facebookDownload(link)

  try {

   res.json({

      Creator: `Akuari.my.id`,

      hasil: hasil.result

      

    })

  } catch (err) {

    console.log(err)

    res.json({ message: 'Ups, error' })

  }


})


  
    



module.exports = router