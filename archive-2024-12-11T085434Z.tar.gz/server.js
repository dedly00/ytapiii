const router = require("express").Router();
//const { getInfo, addInfo, main } = require("./amy/nino");
const { kiss } = require("./amy/kiss");

const { punch } = require("./amy/punch");

const { hug } = require("./amy/hug");

const { clock } = require("./amy/clock");

const { spank } = require("./amy/spank");

const { cuddle } = require("./amy/cuddle");

const { lick } = require("./amy/lick");

const { scared } = require("./amy/scared");

const { slap } = require("./amy/slap");


const { readdirSync, readFileSync } = require('fs-extra');

const path = require('path');
try {
  // ------------------------------------------------------------------------//
  // ------------------------/     Fodel public    /-------------------------//
  // ------------------------------------------------------------------------//
  var i, j, n = 0;
  const srcPath = path.join(__dirname, "/public/");
  const hosting = readdirSync(srcPath).filter((file) => file.endsWith(".js"));
  for (i of hosting) {
    const { index, name } = require(srcPath + i);
    router.get(name, index);
    n++
    console.log(i);
  }

  // for 'post' folder
  //const srcPathPost = path.join(__dirname, "/post/");
  //const hostingPost = readdirSync(srcPathPost).filter((file) => file.endsWith(".js"));
  //for (j of hostingPost) {
    //const { index, name } = require(srcPathPost + j);
    //router.post(name, index);
    //n++
    //console.log('post/' + j);
  


  router.get('/altp_data', function (req, res) {
    const data = JSON.parse(readFileSync('./altp_data.json', "utf-8"));
    res.header("Content-Type", 'application/json');
    res.send(JSON.stringify(data, null, 4));
  });
//router.get("/nino/get/:input", getInfo);

//router.get("/nino/add/:input", addInfo);
router.get("/kiss", kiss);

router.get("/slap", slap);

router.get("/hug", hug);

router.get("/punch", punch);

router.get("/lick", lick);

router.get("/cuddle", cuddle);

router.get("/scared", scared);

router.get("/spank", spank);
router.get("/clock", clock);

  // ------------------------------------------------------------------------//
  // ----------------------------/     Fodel    /----------------------------//
  // ------------------------------------------------------------------------//
  const getDirs = readdirSync(srcPath).filter((file) => !file.endsWith(".js") && !file.endsWith(".json"));
  for (const dir of getDirs) {
    const fileName = readdirSync(path.join(__dirname, '/public/' + dir + '/')).filter((file) => file.endsWith(".js"));
    for (j of fileName) {
      const { index, name } = require(path.join(__dirname, '/public/' + dir + '/') + j);
      router.get(name, index);
      n++
      console.log('\x1b[38;5;220m[ LOADING ] \x1b[33m→\x1b[40m\x1b[1m\x1b[38;5;161m Downloaded successfully ' + j);
    }
  }

  // for 'post' folder
  //const getDirsPost = readdirSync(srcPathPost).filter((file) => !file.endsWith(".js") && !file.endsWith(".json"));
  //for (const dir of getDirsPost) {
    //const fileName = readdirSync(path.join(__dirname, '/post/' + dir + '/')).filter((file) => file.endsWith(".js"));
    //for (j of fileName) {
      //const { index, name } = require(path.join(__dirname, '/post/' + dir + '/') + j);
      //router.post(name, index);
      //n++
      //console.log('\x1b[38;5;220m[ LOADING ] \x1b[33m→\x1b[38;5;197m Downloaded successfully POST/' + j);
    
  
  console.log(`\x1b[38;5;220m[ LOADING ] \x1b[33m→\x1b[38;5;197m Loaded successfully ${n} file API`);
} catch (e) { console.log(e); }

// -------------------------->      END     <------------------------------//

module.exports = router;