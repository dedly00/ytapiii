exports.name = '/pin/downloadpost';
exports.index = async(req, res, next) => {
const url = req.query.url;
if (!url) return res.json({ error: 'Thiếu dữ liệu để khởi chạy chương trình ' });
const axios = require("axios");
 const keyAPi = ['3747b64510msh0388753c12596fcp14b66fjsnb10dbfaa5fcb']
    var keyRandom = keyAPi[Math.floor(Math.random() * keyAPi.length)];
  
  //

const options = {
  method: 'GET',
  url: 'https://pinterest-video-and-image-downloader.p.rapidapi.com/pinterest',
  params: {url: url},
  headers: {
    'X-RapidAPI-Key': keyRandom,
    'X-RapidAPI-Host': 'pinterest-video-and-image-downloader.p.rapidapi.com'
  }
};

axios.request(options).then(function (response) {
	console.log(response.data);
  return res.json(response.data)
}).catch(function (error) {
	console.error(error);
});
}