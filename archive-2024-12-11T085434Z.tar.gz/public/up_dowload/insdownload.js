exports.name = '/instagram/downloadpost';
exports.index = async(req, res, next) => {
const url = req.query.url;
if (!url) return res.json({ error: 'Thiếu dữ liệu để khởi chạy chương trình ' });
const axios = require("axios");
 const keyAPi = ['49b048d945msh42f062dc97b5c03p1dc7d1jsn1c6842d07d0a']
    var keyRandom = keyAPi[Math.floor(Math.random() * keyAPi.length)];
  
  //

const options = {
  method: 'GET',
  url: 'https://instagram-looter2.p.rapidapi.com/post',
  params: {link: url},
  headers: {
    'X-RapidAPI-Key': keyRandom,
    'X-RapidAPI-Host': 'instagram-looter2.p.rapidapi.com'
  }
};

axios.request(options).then(function (response) {
	console.log(response.data);
  return res.json(response.data)
}).catch(function (error) {
	console.error(error);
});
}