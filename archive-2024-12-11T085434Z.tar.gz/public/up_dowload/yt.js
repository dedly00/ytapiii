exports.name = '/yt/downloadpost';
exports.index = async(req, res, next) => {
const url = req.query.url;
if (!url) return res.json({ error: 'Thiếu dữ liệu để khởi chạy chương trình ' });
const axios = require("axios");
 const keyAPi = ['3747b64510msh0388753c12596fcp14b66fjsnb10dbfaa5fcb','45d148678bmsh0598bd3a21d94ddp1c641ajsn10698b2c1535','27646df63fmsh5e7d6f46563a055p159fd5jsn2003b8f30e7b','7ffe11c517msh36bac330c08eee8p132913jsn2fb623d06b16','63257778d6msha71eba4b5e7237cp15c708jsn140a08009f30','5db58d8c59msh3383129aa4b708bp1e3915jsn8685d23d36ed','f01da89a7amsh45af07682b1bb48p1e1c6ajsn5cd685743838','0d93e7bb98mshd6448539beaa2f9p196e0fjsnc0ed23c417e7','60d9cbdc01mshd9ae4dae277651cp153b7fjsn1ef3f52fe9db','bad349450bmsh22b27fd8504a90fp147418jsn049f1fa2510d','23c40a07famshcb4bef6fa788c52p155a8djsn8a08c70e4b21','9ef67e6167mshf340c578ff60e28p1ef200jsnd7af858d504c']
    var keyRandom = keyAPi[Math.floor(Math.random() * keyAPi.length)];
  
  //

const options = {
  method: 'GET',
  url: 'https://youtube-mp3-downloader2.p.rapidapi.com/ytmp3/ytmp3/',
  params: {url: url},
  headers: {
    'X-RapidAPI-Key': keyRandom,
    'X-RapidAPI-Host': 'youtube-mp3-downloader2.p.rapidapi.com'
  }
};

axios.request(options).then(function (response) {
	console.log(response.data);
  return res.json(response.data)
}).catch(function (error) {
	console.error(error);
});
}