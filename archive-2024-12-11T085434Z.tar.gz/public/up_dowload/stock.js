exports.name = '/stock';
exports.index = async(req, res, next) => {
const query = req.query.query;
if (!query) return res.json({ error: 'Thiếu dữ liệu để khởi chạy chương trình ' });
const axios = require("axios");
 const keyAPi = ['3747b64510msh0388753c12596fcp14b66fjsnb10dbfaa5fcb','5db58d8c59msh3383129aa4b708bp1e3915jsn8685d23d36ed']
    var keyRandom = keyAPi[Math.floor(Math.random() * keyAPi.length)];
  
  //

const options = {
  method: 'GET',
  url: 'https://real-time-finance-data.p.rapidapi.com/search',
  params: {query: query},
  headers: {
    'X-RapidAPI-Key': keyRandom,
    'X-RapidAPI-Host': 'real-time-finance-data.p.rapidapi.com'
  }
};

axios.request(options).then(function (response) {
	console.log(response.data);
  return res.json(response.data)
}).catch(function (error) {
	console.error(error);
});
}